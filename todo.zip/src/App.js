import ToDo from "./Components/todo";
function App() {
  return (
    <ToDo />
  );
}

export default App;
