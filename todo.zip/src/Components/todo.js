import React from "react";
import { ReactComponent as Delete } from "../Components/assets/delete.svg";
import { ReactComponent as Revert } from "../Components/assets/revert.svg";
import styled from "styled-components";

class ToDo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [
        {
          id: 1,
          title: "Buy 1 kg tomato",
        },
        {
          id: 2,
          title: "Buy 2 kg onion",
        },
        {
          id: 3,
          title: "Visit friend",
        },
        {
          id: 4,
          title: "Clean house",
        },
      ],
      completedItems: [
        {
          id: 5,
          title: "Washing Clothes",
        },
        {
          id: 6,
          title: "Play Cricket",
        },
        {
          id: 7,
          title: "1 km Walking",
        },
        {
          id: 8,
          title: "Do Homework",
        },
      ],
      idCounter: 9,
    };
  }

  updateItem = () => {
    let new_item = {
      id: this.state.idCounter,
      title: this.state.input,
    };
    if (this.state.input) {
      this.setState({
        items: [...this.state.items, new_item],
        input: "",
        idCounter: this.state.idCounter + 1,
      });
    }
  };

  removeItems = (id) => {
    const { items } = this.state;
    const updatedItems = items.filter((item) => item.id !== id);
    this.setState({
      items: updatedItems,
    });
  };

  completeItem = (id) => {
    const { items, completedItems } = this.state;
    const itemToComplete = items.find((item) => item.id === id);

    if (itemToComplete) {
      const updatedItems = items.filter((item) => item.id !== id);
      this.setState({
        items: updatedItems,
        completedItems: [...completedItems, itemToComplete],
      });
    }
  };

  deleteCompletedItem = (id) => {
    const { completedItems } = this.state;
    const updatedCompletedItems = completedItems.filter(
      (item) => item.id !== id
    );
    this.setState({ completedItems: updatedCompletedItems });
  };

  revertItem = (id) => {
    const { items, completedItems } = this.state;
    const itemToRevert = completedItems.find((item) => item.id === id);

    if (itemToRevert) {
      const updatedCompletedItems = completedItems.filter(
        (item) => item.id !== id
      );
      this.setState({
        items: [...items, itemToRevert],
        completedItems: updatedCompletedItems,
      });
    }
  };

  renderItems = () => {
    return this.state.items.map((item) => (
      <Li1 key={item.id}>
        <Div1>
          <P1 onClick={() => this.completeItem(item.id)}>
            {item.id}, {item.title}{" "}
          </P1>
          <ButtonDel onClick={() => this.removeItems(item.id)}>
            <Delete height={16} />
          </ButtonDel>
        </Div1>
      </Li1>
    ));
  };

  renderCompletedItems = () => {
    return this.state.completedItems.map((item) => (
      <Li2 className="li2" key={item.id}>
        <Div1>
          <P2>
            {item.id}, {item.title}{" "}
          </P2>
          <Div1>
            <ButtonRev onClick={() => this.revertItem(item.id)}>
              <Revert height={16} />
            </ButtonRev>
            <ButtonDel onClick={() => this.deleteCompletedItem(item.id)}>
              <Delete height={16} />
            </ButtonDel>
          </Div1>
        </Div1>
      </Li2>
    ));
  };

  render() {
    return (
      <>
        <Main className="wrapper">
          <Heading1>ToDo List</Heading1>
          <Heading2>Things To Be Done</Heading2>
          <Ul>{this.renderItems()}</Ul>
          <Div2>
            <Input
              placeholder=" Type new task..."
              value={this.state.input}
              onChange={(e) => this.setState({ input: e.target.value })}
            />
            <ButtonSub onClick={this.updateItem}>Add New</ButtonSub>
          </Div2>

          <Heading2>Completed</Heading2>
          <Ul>{this.renderCompletedItems()}</Ul>
        </Main>
      </>
    );
  }
}

const Main = styled.section`
  width: 800px;
  margin: 0 auto;
  padding: 5px 200px;
  border-left: 1px solid grey;
  border-right: 1px solid grey;
`;
const Heading1 = styled.h1`
  font-size: 34px;
  text-align: center;
`;
const Heading2 = styled.h2`
  font-size: 24px;
  color: #040241;
`;
const Ul = styled.ul`
  list-style-type: circle !important;
`;
const Li1 = styled.li`
  margin-bottom: 15px;
  position: relative;

  :first-child::before {
    content: "";
    display: block;
    width: 17px;
    height: 17px;
    border-radius: 50%;
    background-color: #fff;
    margin-right: 10px;
    position: absolute;
    left: -28px;
    top: 50%;
    transform: translateY(-50%);
    border: 2px solid #000;
  }
`;
const Li2 = styled.li`
  margin-bottom: 15px;
`;
const Div1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const Div2 = styled.div`
  display: flex;
  align-items: center;
  position: relative;
  right: -12px;
`;
const P1 = styled.p`
  font-size: 19px;
  margin: 0;
  &:hover {
    cursor: pointer;
  }
  flex: 1;
`;
const P2 = styled.p`
  font-size: 19px;
  margin: 0;
  color: #10c694;
`;
const ButtonDel = styled.button`
  background-color: #fff;
  border: none;
  height: 16px;
  &:hover {
    cursor: pointer;
  }
`;
const ButtonRev = styled.button`
  background-color: #fff;
  border: none;
  height: 16px;
  margin-right: 5px;
  &:hover {
    cursor: pointer;
  }
`;
const ButtonSub = styled.button`
  border: none;
  width: 82px;
  height: auto;
  background-color: #040241;
  color: #fff;
  &:hover {
    cursor: pointer;
  }
  padding: 12px 8px;
`;
const Input = styled.input`
  width: 75%;
  &::-webkit-input-placeholder {
    position: relative;
    padding-left: 20px; 
    background-image: url(${require("../Components/assets/plus.svg").default});
    background-repeat: no-repeat;
    background-position: left center;
    background-size: 14px 14px;
  }
  padding: 10px 5px;
`;

export default ToDo;
